package com.example.edentranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

class TranslateService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.edentranslator.STOP"
        private const val CHANNEL = "eden_translate"
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var latest: Image? = null
    private val lock = Any()
    private var w = 0
    private var h = 0
    private var dpi = 0

    private var button: TextView? = null
    private var overlay: OverlayView? = null
    private var recognizer: TextRecognizer? = null
    private var translator: Translator? = null
    private var glossary: List<Pair<String, String>> = emptyList()

    private var busy = false
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started || intent == null) return START_NOT_STICKY
        started = true

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()

        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        setupMl(intent.getStringExtra("lang") ?: "en")
        loadGlossary()
        setupProjection(code, data)
        showButton()
        return START_NOT_STICKY
    }

    // ---------- foreground notification ----------

    @Suppress("DEPRECATION")
    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "EDEN Translator", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("EDEN Thai Translator")
            .setContentText("แตะปุ่มลอยบนหน้าจอเพื่อแปล")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(0, "หยุด", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- ML Kit ----------

    private fun setupMl(lang: String) {
        recognizer = if (lang == "ko") {
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        } else {
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }
        val src = if (lang == "ko") TranslateLanguage.KOREAN else TranslateLanguage.ENGLISH
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(TranslateLanguage.THAI)
                .build()
        )
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnFailureListener { toast("โหลดโมเดลแปลไม่สำเร็จ ต้องต่อเน็ตในครั้งแรก") }
    }

    private fun loadGlossary() {
        glossary = try {
            assets.open("glossary.txt").bufferedReader().readLines()
                .filter { it.contains("=") && !it.trimStart().startsWith("#") }
                .map { it.substringBefore("=").trim() to it.substringAfter("=").trim() }
                .filter { it.first.isNotEmpty() }
                .sortedByDescending { it.first.length }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // แทนที่ศัพท์เฉพาะด้วยคำไทยก่อนส่งแปล (ทำงานได้ดีระดับหนึ่ง ไม่รับประกัน 100%)
    private fun applyGlossary(text: String): String {
        var s = text
        for ((k, v) in glossary) s = s.replace(k, v, ignoreCase = true)
        return s
    }

    // ---------- screen capture ----------

    private fun readScreenSize() {
        val dm = DisplayMetrics()
        val d = getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)
        @Suppress("DEPRECATION")
        d.getRealMetrics(dm)
        w = dm.widthPixels
        h = dm.heightPixels
        dpi = dm.densityDpi
    }

    private fun newReader(): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = (try {
                rd.acquireLatestImage()
            } catch (e: Exception) {
                null
            }) ?: return@setOnImageAvailableListener
            synchronized(lock) {
                latest?.close()
                latest = img
            }
        }, handler)
        return r
    }

    private fun setupProjection(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                handler.post { stopSelf() }
            }
        }, handler)
        projection = p

        readScreenSize()
        val r = newReader()
        reader = r
        vDisplay = p.createVirtualDisplay(
            "eden-capture", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    // รองรับการหมุนจอ (แนวตั้ง/แนวนอน)
    private fun ensureDisplaySize() {
        val ow = w
        val oh = h
        readScreenSize()
        if (ow != w || oh != h) {
            val old = reader
            val r = newReader()
            reader = r
            synchronized(lock) {
                latest?.close()
                latest = null
            }
            vDisplay?.resize(w, h, dpi)
            vDisplay?.surface = r.surface
            old?.close()
        }
    }

    private fun latestBitmap(): Bitmap? {
        synchronized(lock) {
            val img = latest ?: return null
            val plane = img.planes[0]
            val rowPixels = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(rowPixels, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            return if (rowPixels != img.width) {
                Bitmap.createBitmap(full, 0, 0, img.width, img.height)
            } else full
        }
    }

    // ---------- floating button ----------

    private fun showButton() {
        val d = resources.displayMetrics.density
        val size = (56 * d).toInt()
        val tv = TextView(this).apply {
            text = "แปล"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC1E88E5.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (16 * d).toInt()
            y = (200 * d).toInt()
        }

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var downAt = 0L
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                    moved = false
                    downAt = SystemClock.uptimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = ox + dx.toInt()
                        lp.y = oy + dy.toInt()
                        wm.updateViewLayout(tv, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (SystemClock.uptimeMillis() - downAt > 1000) stopSelf() else capture()
                    }
                }
            }
            true
        }
        wm.addView(tv, lp)
        button = tv
    }

    // ---------- capture -> OCR -> translate -> overlay ----------

    private fun capture() {
        if (busy) return
        busy = true
        removeOverlay()
        button?.visibility = View.INVISIBLE
        ensureDisplaySize()
        handler.postDelayed({ grab() }, 350) // รอให้เฟรมใหม่ที่ไม่มีปุ่ม/คำแปลเข้ามา
    }

    private fun grab() {
        val bmp = try {
            latestBitmap()
        } catch (e: Exception) {
            null
        }
        button?.visibility = View.VISIBLE
        if (bmp == null) {
            toast("จับภาพหน้าจอไม่สำเร็จ ลองอีกครั้ง")
            busy = false
            return
        }
        recognizer!!.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text -> translateAll(text) }
            .addOnFailureListener {
                toast("อ่านข้อความไม่สำเร็จ")
                busy = false
            }
    }

    private fun translateAll(text: Text) {
        val blocks = text.textBlocks.filter { b ->
            b.boundingBox != null && b.text.count { it.isLetter() } >= 2
        }
        if (blocks.isEmpty()) {
            toast("ไม่พบข้อความบนหน้าจอ")
            busy = false
            return
        }
        val tr = translator!!
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                val results = arrayOfNulls<OverlayView.Item>(blocks.size)
                var pending = blocks.size
                blocks.forEachIndexed { i, b ->
                    val src = applyGlossary(b.text.replace("\n", " "))
                    tr.translate(src).addOnCompleteListener { t ->
                        if (t.isSuccessful) results[i] = OverlayView.Item(Rect(b.boundingBox!!), t.result)
                        pending--
                        if (pending == 0) showOverlay(results.filterNotNull())
                    }
                }
            }
            .addOnFailureListener {
                toast("ยังไม่มีโมเดลแปล กรุณาต่ออินเทอร์เน็ต")
                busy = false
            }
    }

    private fun showOverlay(items: List<OverlayView.Item>) {
        busy = false
        if (items.isEmpty()) return
        val v = OverlayView(this, items)
        v.setOnClickListener { removeOverlay() }
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        }
        wm.addView(v, lp)
        overlay = v
    }

    private fun removeOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    private fun toast(msg: String) {
        handler.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    }

    override fun onDestroy() {
        removeOverlay()
        button?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        button = null
        synchronized(lock) {
            latest?.close()
            latest = null
        }
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        recognizer?.close()
        translator?.close()
        super.onDestroy()
    }
}
