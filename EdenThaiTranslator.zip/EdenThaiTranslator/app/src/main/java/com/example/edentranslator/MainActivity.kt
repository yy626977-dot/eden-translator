package com.example.edentranslator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : Activity() {

    private val reqProjection = 1001
    private val reqNotif = 1002
    private var lang = "en"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "EDEN Thai Translator"
            textSize = 22f
        })
        root.addView(TextView(this).apply {
            text = "วิธีใช้\n" +
                "1) เลือกภาษาในเกม แล้วกด \"เริ่ม\" (ครั้งแรกต้องต่อเน็ตเพื่อโหลดโมเดลแปล)\n" +
                "2) อนุญาตสิทธิ์แสดงทับแอปอื่น และการบันทึกหน้าจอ\n" +
                "3) เปิดเกม จะมีปุ่ม \"แปล\" ลอยอยู่ แตะเพื่อแปลหน้าจอ แตะที่คำแปลเพื่อปิด\n" +
                "4) ลากปุ่มเพื่อย้ายตำแหน่ง กดค้าง 1 วินาทีเพื่อหยุดโปรแกรม"
            setPadding(0, pad / 2, 0, pad / 2)
        })

        val group = RadioGroup(this)
        val en = RadioButton(this).apply { text = "ภาษาในเกม: อังกฤษ"; id = 1; isChecked = true }
        val ko = RadioButton(this).apply { text = "ภาษาในเกม: เกาหลี"; id = 2 }
        group.addView(en)
        group.addView(ko)
        group.setOnCheckedChangeListener { _, checked -> lang = if (checked == 2) "ko" else "en" }
        root.addView(group)

        root.addView(Button(this).apply {
            text = "เริ่ม"
            setOnClickListener { start() }
        })
        root.addView(Button(this).apply {
            text = "หยุด"
            setOnClickListener {
                startService(Intent(this@MainActivity, TranslateService::class.java)
                    .setAction(TranslateService.ACTION_STOP))
            }
        })

        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), reqNotif)
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == reqNotif) start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqProjection && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, TranslateService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("lang", lang)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
