package com.example.edentranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View
import kotlin.math.max

class OverlayView(ctx: Context, private val items: List<Item>) : View(ctx) {

    data class Item(val box: Rect, val text: String)

    private val d = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xEE0F1720.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = 6 * d
        for (item in items) {
            val box = item.box
            val boxW = max(box.width(), (180 * d).toInt()).coerceAtMost(width)
            val textW = (boxW - 2 * pad).toInt().coerceAtLeast(1)

            // เริ่มจากขนาดตัวอักษรตามความสูงกล่อง แล้วลดลงจนพอดี
            var size = (box.height() * 0.8f).coerceIn(14 * d, 26 * d)
            val minSize = 12 * d
            val targetH = max(box.height().toFloat(), 40 * d)
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder
                    .obtain(item.text, 0, item.text.length, tp, textW)
                    .setLineSpacing(0f, 1.15f)
                    .build()
                if (layout.height + 2 * pad <= targetH || size <= minSize) break
                size -= d
            }

            val boxH = layout.height + 2 * pad
            val left = box.left.toFloat().coerceIn(0f, (width - boxW).toFloat().coerceAtLeast(0f))
            val top = box.top.toFloat().coerceAtMost(height - boxH).coerceAtLeast(0f)

            canvas.drawRoundRect(RectF(left, top, left + boxW, top + boxH), 8 * d, 8 * d, bg)
            canvas.save()
            canvas.translate(left + pad, top + pad)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
